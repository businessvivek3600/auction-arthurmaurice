import 'package:action_tds/lib/laravel_echo.dart';
import 'package:action_tds/utils/size_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pusher_client/pusher_client.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class AppState extends InheritedWidget {
  final List<LogString> logs;
  final ValueChanged<String> log;

  const AppState({
    Key? key,
    required this.logs,
    required this.log,
    required Widget child,
  }) : super(key: key, child: child);

  static AppState of(BuildContext context) {
    final AppState? result =
        context.dependOnInheritedWidgetOfExactType<AppState>();
    assert(result != null, 'No AppState found in context');
    return result!;
  }

  @override
  bool updateShouldNotify(AppState old) {
    return true;
  }
}

class LogString {
  final String date;
  final String text;

  LogString({
    required this.date,
    required this.text,
  });
}

class ChannelOptions {
  final String channelName;
  final ChannelType channelType;
  final String event;

  ChannelOptions(this.channelName, this.channelType, this.event);
}

enum ChannelType {
  public,
  private,
  presence,
}

class ListenToChannelModal extends StatefulWidget {
  final ValueChanged<ChannelOptions> onListen;

  const ListenToChannelModal({
    Key? key,
    required this.onListen,
  }) : super(key: key);

  _ListenToChannelModalState createState() => _ListenToChannelModalState();
}

class _ListenToChannelModalState extends State<ListenToChannelModal> {
  String channelName = 'bid-channel';
  String event = 'new-bid';
  ChannelType channelType = ChannelType.public;
  late TextEditingController channelNameController;
  late TextEditingController eventController;

  @override
  void initState() {
    super.initState();
    channelNameController = TextEditingController(text: channelName);
    eventController = TextEditingController(text: event);
  }

  void onChannelTypeChange(ChannelType value) {
    switch (value) {
      case ChannelType.private:
        channelName = 'private-channel.1';
        event = 'PrivateEvent';
        break;
      case ChannelType.presence:
        channelName = 'presence-channel.1';
        event = 'PresenceEvent';
        break;
      default:
        channelName = 'public-channel';
        event = 'PublicEvent';
        break;
    }

    setState(() {
      channelNameController.text = channelName;
      eventController.text = event;
      channelType = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      // color: Colors.white,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          CupertinoSegmentedControl<ChannelType>(
            groupValue: channelType,
            onValueChanged: onChannelTypeChange,
            children: const {
              ChannelType.public: Text('public'),
              ChannelType.private: Text('private'),
              ChannelType.presence: Text('presence'),
            },
          ),
          const SizedBox(height: 25),
          TextField(
            controller: channelNameController,
            decoration: const InputDecoration(
              filled: false,
              labelText: 'Channel name',
              border: OutlineInputBorder(),
              contentPadding: EdgeInsets.symmetric(
                vertical: 8,
                horizontal: 12,
              ),
            ),
            onChanged: (String value) {
              setState(() => channelName = value);
            },
          ),
          const SizedBox(height: 20),
          TextField(
            controller: eventController,
            decoration: const InputDecoration(
              filled: false,
              labelText: 'Event name',
              border: OutlineInputBorder(),
              contentPadding: EdgeInsets.symmetric(
                vertical: 8,
                horizontal: 12,
              ),
            ),
            onChanged: (String value) {
              setState(() => event = value);
            },
          ),
          const SizedBox(height: 25),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              fixedSize: const Size.fromHeight(44),
            ),
            child: const Text('Listen'),
            onPressed: () {
              if (channelName.isEmpty || event.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Please fill all fields'),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
                return;
              }

              widget.onListen(ChannelOptions(
                channelName,
                channelType,
                event,
              ));
            },
          ),
        ],
      ),
    );
  }
}

const String BEARER_TOKEN = 'YOUR_BEARER_TOKEN_HERE';

Echo initSocketIOClient() {
  IO.Socket socket = IO.io(
    'http://localhost:6002',
    IO.OptionBuilder()
        .disableAutoConnect()
        .setTransports(['websocket']).build(),
  );

  Echo echo = Echo(
    broadcaster: EchoBroadcasterType.SocketIO,
    client: socket,
    options: {
      'auth': {
        'headers': {
          'Authorization': 'Bearer $BEARER_TOKEN',
        }
      },
    },
  );

  return echo;
}

const String PUSHER_KEY = 'ap2';
// const String PUSHER_KEY = 'YOUR_PUSHER_KEY_HERE';
const String PUSHER_CLUSTER = 'ap2';
const String AUTH_URL = 'http://echo.test/api/broadcasting/auth';

Echo initPusherClient() {
  PusherOptions options;

  if (PUSHER_KEY == 'local') {
    //
    // Sample configuration for laravel-websockets
    //
    options = PusherOptions(
      host: '127.0.0.1',
      wsPort: 6001,
      encrypted: false,
      auth: PusherAuth(
        AUTH_URL,
        headers: {
          'Authorization': 'Bearer $BEARER_TOKEN',
        },
      ),
    );
  } else {
    //
    // Sample configuration for pusher
    //
    options = PusherOptions(
      cluster: PUSHER_CLUSTER,
      encrypted: false,
      auth: PusherAuth(
        AUTH_URL,
        headers: {
          'Authorization': 'Bearer $BEARER_TOKEN',
        },
      ),
    );
  }

  PusherClient pusherClient = PusherClient(
    PUSHER_KEY,
    options,
    autoConnect: true,
    enableLogging: true,
  );

  pusherClient.onConnectionError((error) {
    print(error?.message);
  });

  Echo echo = Echo(
    broadcaster: EchoBroadcasterType.Pusher,
    client: pusherClient,
  );

  return echo;
}

///ui
class ActionsView extends StatefulWidget {
  final String broadcaster;

  const ActionsView({
    Key? key,
    required this.broadcaster,
  });

  @override
  State<StatefulWidget> createState() => _ActionsView();
}

class _ActionsView extends State<ActionsView> {
  late Echo echo;
  late AppState appState;
  late Function log;
  bool isConnected = false;
  List<String> listeningChannels = [];

  @override
  void initState() {
    super.initState();

    initEcho();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      appState = AppState.of(context);
      log = appState.log;
    });
  }

  @override
  void didUpdateWidget(ActionsView old) {
    super.didUpdateWidget(old);

    if (old.broadcaster == widget.broadcaster) return;

    echo.disconnect();
    initEcho();
  }

  void initEcho() {
    if (widget.broadcaster == 'pusher') {
      echo = initPusherClient();

      echo.connector.pusher.onConnectionStateChange((state) {
        log('pusher ${state!.currentState}');

        if (state.currentState == 'connected') {
          setState(() => isConnected = true);
        } else {
          setState(() => isConnected = false);
        }
      });
    } else {
      echo = initSocketIOClient();

      (echo.connector.socket as IO.Socket).onConnect((_) {
        log('socket.io connected');
        setState(() => isConnected = true);
      });

      (echo.connector.socket as IO.Socket).onDisconnect((_) {
        log('socket.io disconnected');
        setState(() => isConnected = false);
      });
    }
  }

  void listenToChannel(ChannelType type, String name, String event) {
    dynamic channel;

    if (type == ChannelType.public) {
      channel = echo.channel(name);
    } else if (type == ChannelType.private) {
      channel = echo.private(name);
    } else if (type == ChannelType.presence) {
      channel = echo.join(name).here((users) {
        print(users);
      }).joining((user) {
        print(user);
      }).leaving((user) {
        print(user);
      });
    }

    channel.listen(event, (e) {
      if (e == null) return;

      /**
       * Handle pusher event
       */
      if (e is PusherEvent) {
        String _text = 'channel: ${e.channelName}, event: ${e.eventName}';

        if (e.data != null) {
          _text += ', data: ${e.data}';
        }

        if (e.userId != null) {
          _text += ', userId: ${e.userId}';
        }

        log(_text);
        return;
      }

      print('event: $e');
      log('event: $e');
    });
  }

  @override
  void dispose() {
    echo.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        ListTile(
          title: Text(
            isConnected ? 'disconnect' : 'connect',
            style: const TextStyle(
              color: Colors.blue,
              fontWeight: FontWeight.w500,
            ),
          ),
          trailing: ClipOval(
            child: Container(
              color: isConnected ? Colors.green : Colors.red,
              height: 20,
              width: 20,
            ),
          ),
          onTap: () {
            isConnected ? echo.disconnect() : echo.connect();
          },
        ),
        ListTile(
          title: const Text(
            'listen to channel',
            style: TextStyle(
              color: Colors.blue,
              fontWeight: FontWeight.w500,
            ),
          ),
          trailing: ClipOval(
            child: Container(
              color: Colors.grey[400],
              height: 20,
              width: 20,
              child: Center(
                child: Text(
                  listeningChannels.length.toString(),
                ),
              ),
            ),
          ),
          onTap: () {
            showModalBottomSheet(
              context: context,
              backgroundColor: getTheme(context).scaffoldBackgroundColor,
              builder: (_) => Scaffold(
                body: ListenToChannelModal(
                  onListen: (ChannelOptions options) {
                    String channelType =
                        options.channelType.toString().substring(12);

                    log('Listening to $channelType channel: ${options.channelName}');

                    listenToChannel(
                      options.channelType,
                      options.channelName,
                      options.event,
                    );

                    if (!listeningChannels.contains(options.channelName)) {
                      setState(() {
                        listeningChannels.add(options.channelName);
                      });
                    }

                    Navigator.of(context).pop();
                  },
                ),
              ),
            );
          },
        ),
        ListTile(
          title: const Text(
            'leave channel',
            style: TextStyle(
              color: Colors.blue,
              fontWeight: FontWeight.w500,
            ),
          ),
          onTap: () {
            showModalBottomSheet(
              context: context,
              builder: (_) => LeaveChannelModal(
                listeningChannels: listeningChannels,
                onLeave: (String? channelName) {
                  if (channelName != null) {
                    listeningChannels.remove(channelName);
                    log('Leaving channel: $channelName');
                    echo.leave(channelName);
                  }

                  Navigator.of(context).pop();
                },
              ),
            );
          },
        ),
        ListTile(
          title: const Text(
            'get socket-id',
            style: TextStyle(
              color: Colors.blue,
              fontWeight: FontWeight.w500,
            ),
          ),
          onTap: () => log('socket-id: ${echo.socketId()}'),
        ),
      ],
    );
  }
}

class LeaveChannelModal extends StatefulWidget {
  final ValueChanged<String?> onLeave;
  final List<String> listeningChannels;

  const LeaveChannelModal({
    Key? key,
    required this.onLeave,
    required this.listeningChannels,
  }) : super(key: key);

  _LeaveChannelModalState createState() => _LeaveChannelModalState();
}

class _LeaveChannelModalState extends State<LeaveChannelModal> {
  late String name;
  late TextEditingController nameController;

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController();
    if (widget.listeningChannels.isNotEmpty) {
      name = widget.listeningChannels.first;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.listeningChannels.isEmpty) {
      return Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'No listening channels',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Close'),
            ),
          ],
        ),
      );
    }

    return Container(
      color: Colors.white,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          DropdownButton<String>(
            value: name,
            isExpanded: true,
            hint: const Text('Please choose channel name'),
            items: widget.listeningChannels.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
            onChanged: (String? value) {
              setState(() => name = value!);
            },
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              fixedSize: const Size.fromHeight(44),
            ),
            child: const Text(
              'Leave',
              style: TextStyle(fontSize: 16),
            ),
            onPressed: () => widget.onLeave(name),
          ),
        ],
      ),
    );
  }
}
