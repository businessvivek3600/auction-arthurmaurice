import 'dart:convert';
import 'dart:developer';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../../../../database/init_get_storages.dart';
import '../../auth/user_model.dart';

class AppUserProvider {
  static const tag = 'AppUserProvider';
  static const String _tableName = 'users';
  static GetStorage appUserBox = GetStorage(LocalStorage.userBox);
  AppUserProvider._();
  static AppUserProvider? _instance;
  static AppUserProvider get instance {
    _instance ??= AppUserProvider._();
    // await GetStorage.init(_tableName)
    //     .then((_) => appUserBox = GetStorage(_tableName));
    // logger.d('$tag instance ${appUserBox.getKeys()}', tag: tag);
    return _instance!;
  }

  /// all social app accounts
  List<AuctionUser> users = [];

  Future<List<AuctionUser>> getAllUsers() async {
    try {
      final data = jsonDecode(appUserBox.read(_tableName) ?? '[]') as List;
      users = data.map((e) => AuctionUser.fromJson(e)).toList();
    } catch (e) {
      Get.snackbar('Error', e.toString());
      log('getAllUsers error: $e');
    }
    return users;
  }

  /// store new user in users in local storage
  Future<void> storeNewUser(AuctionUser user) async {
    try {
      /// check if user already exists
      users.firstWhereOrNull((element) => element.id == user.id) == null
          ? users.add(user)
          : () {
              /// update user
              users[users.indexWhere((element) => element.id == user.id)] =
                  user;
            };
      await appUserBox.write(
          _tableName, jsonEncode(users.map((e) => e.toJson()).toList()));
      await getAllUsers();
    } catch (e) {
      log('storeNewUser error: $e');
    }
  }

  /// update user in users in local storage
  Future<void> updateUser(AuctionUser user) async {
    List<AuctionUser> users = await getAllUsers();
    users[users.indexWhere((element) => element.id == user.id)] = user;
    await appUserBox.write(
        _tableName, jsonEncode(users.map((e) => e.toJson()).toList()));
  }

  /// delete user in users in local storage
  Future<void> deleteUserFromStorage(int id) async {
    List<AuctionUser> users = await getAllUsers();
    users.removeWhere((element) => element.id == id);
    await appUserBox.write(
        _tableName, jsonEncode(users.map((e) => e.toJson()).toList()));
  }

  /// get user from users in local storage
  Future<AuctionUser?> getUserFromStorage(int? id) async {
    List<AuctionUser> users = await getAllUsers();
    return users.firstWhereOrNull((element) => element.id == id);
  }
}
